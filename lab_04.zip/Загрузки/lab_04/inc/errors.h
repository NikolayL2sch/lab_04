#ifndef _ERRORS_H
#define _ERRORS_H

void print_error(const int rc);

#endif //_ERRORS_H