#ifndef MENU_H
#define MENU_H

void print_menu(void);
int menu(int *choice);

#endif